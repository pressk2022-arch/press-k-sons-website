import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";

export default function App() {
  return (
    <div style={{fontFamily:"Arial, sans-serif", lineHeight:1.6}}>
      <a
        href="https://wa.me/255759444058"
        target="_blank"
        style={{
          position:"fixed",
          bottom:"20px",
          right:"20px",
          background:"#25D366",
          color:"#fff",
          padding:"14px",
          borderRadius:"50%",
          textDecoration:"none"
        }}
      >
        <MessageCircle />
      </a>

      <header style={{padding:"20px", background:"#1e40af", color:"#fff", textAlign:"center"}}>
        <h1>Press K & Sons General Enterprises</h1>
      </header>

      <section style={{padding:"40px", textAlign:"center"}}>
        <motion.h2 initial={{opacity:0,y:40}} animate={{opacity:1,y:0}}>
          Protecting Rights. Empowering Communities.
        </motion.h2>
        <p>
          We promote human rights and community protection across Tanzania.
        </p>
      </section>

      <section style={{padding:"40px", background:"#f1f5f9"}}>
        <h3 style={{textAlign:"center"}}>Contact Us</h3>
        <p style={{textAlign:"center"}}>
          Ubungo, Dar es Salaam<br/>
          pressk2022@gmail.com<br/>
          +255 759 444 058
        </p>
      </section>

      <footer style={{padding:"20px", background:"#1e40af", color:"#fff", textAlign:"center"}}>
        © {new Date().getFullYear()} Press K & Sons General Enterprises
      </footer>
    </div>
  );
}
